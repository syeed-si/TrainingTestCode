﻿using sample.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace sample.Repositories
{
    public interface ITrainingRepository : IGenericRepository<TrainingData>
    {

    }
}